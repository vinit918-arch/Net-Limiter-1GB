package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_BOOT_COMPLETED == intent.action) {
            Log.d("NetLimitBootReceiver", "Device boot detected. Re-initializing traffic monitors.")

            val prefs: SharedPreferences = context.getSharedPreferences("netlimit_prefs", Context.MODE_PRIVATE)
            
            // On device boot, TrafficStats resets to zero. We must clear last system readings 
            // so we do not calculate huge negative changes or huge incorrect counts.
            prefs.edit()
                .putLong("last_system_total", 0L)
                .putLong("last_system_mobile", 0L)
                .apply()

            // If the NetLimit VPN firewall is configured to be active, trigger start
            val isFirewallActivated = prefs.getBoolean("firewall_enabled", true)
            if (isFirewallActivated) {
                val serviceIntent = Intent(context, MyVpnService::class.java).apply {
                    action = MyVpnService.ACTION_START
                }
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                    Log.i("NetLimitBootReceiver", "Successfully relaunched NetLimit VPN service on boot.")
                } catch (e: Exception) {
                    Log.e("NetLimitBootReceiver", "Failed to start service on boot: ${e.message}")
                }
            }
        }
    }
}
