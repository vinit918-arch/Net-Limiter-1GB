package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request runtime notifications permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        }

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold")
                ) { innerPadding ->
                    FirewallDashboard(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Bento Grid Design - Primary Palette Tokens
val BentoLightBg = Color(0xFFFDF7FF)
val BentoAccentPurple = Color(0xFF6750A4)
val BentoDeepPurpleText = Color(0xFF21005D)
val BentoUsageCardBg = Color(0xFFEADDFF)
val BentoSoftLavenderBg = Color(0xFFF3EDF7)
val BentoBorderGray = Color(0xFFCAC4D0)
val BentoBorderLight = Color(0xFFE7E0EC)
val BentoTextDark = Color(0xFF1C1B1F)

val BlueWifi = Color(0xFF38BDF8)
val RedCellular = Color(0xFFF43F5E)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirewallDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("netlimit_prefs", Context.MODE_PRIVATE) }

    // Synchronized local UI states
    var todayUsageTotal by remember { mutableStateOf(0L) }
    var todayUsageMobile by remember { mutableStateOf(0L) }
    var dailyLimitBytes by remember { mutableStateOf(1024 * 1024 * 1024L) } // 1GB default
    var firewallEnabled by remember { mutableStateOf(true) }
    var savedPinCode by remember { mutableStateOf("") }
    var isVpnActiveState by remember { mutableStateOf(false) }
    var isVpnBlockingState by remember { mutableStateOf(false) }

    // Sheet / Dialog overlays
    var showPinPadDialog by remember { mutableStateOf(false) }
    var pendingActionAfterPin by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showSecurityMenuDialog by remember { mutableStateOf(false) }

    // Synchronized Inline Limit values (Inputs mapping directly to HTML bento spec)
    var inputAmount by remember { mutableStateOf("") }
    var inputUnit by remember { mutableStateOf("GB") }

    val mbVal = 1014 * 1024L
    val gbVal = mbVal * 1024L

    // Notification helper
    fun updateLocalStates() {
        todayUsageTotal = prefs.getLong("today_usage_total", 0L)
        todayUsageMobile = prefs.getLong("today_usage_mobile", 0L)
        dailyLimitBytes = prefs.getLong("daily_limit_bytes", 1024 * 1024 * 1024L)
        firewallEnabled = prefs.getBoolean("firewall_enabled", true)
        savedPinCode = prefs.getString("pin_code", "") ?: ""
        isVpnActiveState = MyVpnService.isServiceRunning
        isVpnBlockingState = MyVpnService.isVpnBlocking
    }

    // Initialize local Amount/Unit input text based on saved preference data
    LaunchedEffect(dailyLimitBytes) {
        val currentGb = 1024 * 1024 * 1024L
        val currentMb = 1024 * 1024L
        if (dailyLimitBytes >= currentGb) {
            val num = (dailyLimitBytes.toDouble() / currentGb.toDouble())
            inputAmount = if (num == num.toInt().toDouble()) num.toInt().toString() else String.format(Locale.US, "%.1f", num)
            inputUnit = "GB"
        } else {
            val num = (dailyLimitBytes.toDouble() / currentMb.toDouble())
            inputAmount = if (num == num.toInt().toDouble()) num.toInt().toString() else String.format(Locale.US, "%.1f", num)
            inputUnit = "MB"
        }
    }

    // Trigger state reads immediately and periodically every 1 sec
    LaunchedEffect(Unit) {
        while (true) {
            updateLocalStates()
            delay(1000)
        }
    }

    // VPN Authorization permission launcher
    val vpnAuthorizeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            // Permission granted, start VPN background service safely
            triggerServiceIntent(context, MyVpnService.ACTION_START)
            updateLocalStates()
            Toast.makeText(context, "VPN Shield Started Successfully", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "VPN permission is required to enforce data block limits.", Toast.LENGTH_LONG).show()
        }
    }

    fun handleStartFirewall() {
        val vpnIntent = VpnService.prepare(context)
        if (vpnIntent != null) {
            vpnAuthorizeLauncher.launch(vpnIntent)
        } else {
            triggerServiceIntent(context, MyVpnService.ACTION_START)
            updateLocalStates()
        }
    }

    fun handleStopFirewall() {
        triggerServiceIntent(context, MyVpnService.ACTION_STOP)
        updateLocalStates()
    }

    // PIN Gate before any changes
    fun executeWithPinVerification(action: () -> Unit) {
        if (savedPinCode.isEmpty()) {
            // No lock screen PIN set yet, direct bypass to the settings
            action()
        } else {
            pendingActionAfterPin = action
            showPinPadDialog = true
        }
    }

    // Save action for the Limit parameters
    val saveLimitAction = {
        val rawNum = inputAmount.toDoubleOrNull() ?: 1.0
        val calculatedBytes = if (inputUnit == "GB") {
            (rawNum * 1024 * 1024 * 1024L).toLong()
        } else {
            (rawNum * 1024 * 1024L).toLong()
        }
        prefs.edit().putLong("daily_limit_bytes", calculatedBytes).apply()
        // Ask background service to immediately evaluate updated limits
        triggerServiceIntent(context, MyVpnService.ACTION_REVALUATE)
        updateLocalStates()
        Toast.makeText(context, "Firewall limits saved successfully", Toast.LENGTH_SHORT).show()
    }

    // Layout Composition - Clean, Modern Bento Grid Theme on Lavender Background
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BentoLightBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Scrollable content area
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Block
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NetLimit",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoTextDark,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = if (isVpnActiveState) "VPN SERVICE ACTIVE" else "VPN SERVICE STANDBY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoAccentPurple,
                        letterSpacing = 0.5.sp
                    )
                }

                // Header Custom Toggle Switch matching the HTML design precisely
                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .height(24.dp)
                        .clip(CircleShape)
                        .background(if (isVpnActiveState) BentoAccentPurple else BentoBorderGray)
                        .clickable {
                            if (isVpnActiveState) {
                                executeWithPinVerification { handleStopFirewall() }
                            } else {
                                handleStartFirewall()
                            }
                        }
                        .testTag("firewall_toggle_btn")
                        .padding(horizontal = 4.dp),
                    contentAlignment = if (isVpnActiveState) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .shadow(1.dp, CircleShape)
                    )
                }
            }

            // Central Bento Grid Items:
            
            // Bento Box 1: Large usage meter (2 spans row background card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(BentoUsageCardBg)
                    .testTag("status_card")
                    .padding(24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.5f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "DAILY USAGE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoDeepPurpleText,
                                letterSpacing = 1.sp
                            )
                        }

                        // Reset Statistics Trigger (floating inside layout cleanly)
                        IconButton(
                            onClick = {
                                executeWithPinVerification {
                                    prefs.edit().putLong("today_usage_total", 0L).putLong("today_usage_mobile", 0L).apply()
                                    triggerServiceIntent(context, MyVpnService.ACTION_REVALUATE)
                                    updateLocalStates()
                                    Toast.makeText(context, "Statistics reset successfully", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.3f))
                                .testTag("reset_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Manual reset metrics",
                                tint = BentoDeepPurpleText,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Large dynamic percentage display text
                    val progressRatio = if (dailyLimitBytes > 0) {
                        (todayUsageTotal.toFloat() / dailyLimitBytes.toFloat()).coerceIn(0f, 1f)
                    } else 0f
                    val percentage = (progressRatio * 100).toInt()

                    Row(
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "$percentage",
                            fontSize = 62.sp,
                            fontWeight = FontWeight.Light,
                            color = BentoDeepPurpleText,
                            lineHeight = 62.sp
                        )
                        Text(
                            text = "%",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Normal,
                            color = BentoDeepPurpleText,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        Spacer(modifier = Modifier.weight(1f))
                        
                        Text(
                            text = formatBytes(todayUsageTotal) + " / " + formatBytes(dailyLimitBytes),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            color = BentoDeepPurpleText,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Thick beautiful bento progress bar indicator
                    val animatedProgress by animateFloatAsState(
                        targetValue = progressRatio,
                        animationSpec = tween(durationMillis = 800, easing = LinearOutSlowInEasing),
                        label = "bento_meter"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(CircleShape)
                            .background(BentoDeepPurpleText.copy(alpha = 0.1f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(animatedProgress)
                                .clip(CircleShape)
                                .background(BentoAccentPurple)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Remaining usage caption
                    val remainingBytes = (dailyLimitBytes - todayUsageTotal).coerceAtLeast(0L)
                    Text(
                        text = if (isVpnBlockingState) {
                            "0 Bytes quota remaining. Silently dropping network packets."
                        } else {
                            formatBytes(remainingBytes) + " remaining before auto-block limit."
                        },
                        fontSize = 12.sp,
                        color = BentoDeepPurpleText.copy(alpha = 0.7f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Bento Box 2 & 3: Speed/Analytics Grid (Row containing Wi-Fi vs Mobile usage blocks)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val wifiBytes = (todayUsageTotal - todayUsageMobile).coerceAtLeast(0L)
                
                // Wifi Metric Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BentoBorderGray)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "WIFI TRAFFIC",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextDark.copy(alpha = 0.5f),
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Wifi stats",
                            tint = BlueWifi,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = formatBytes(wifiBytes),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = BentoTextDark
                        )
                    }
                }

                // Cellular Metric Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BentoBorderGray)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "MOBILE DATA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextDark.copy(alpha = 0.5f),
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Icon(
                            imageVector = Icons.Default.SignalCellularAlt,
                            contentDescription = "Cellular stats",
                            tint = RedCellular,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = formatBytes(todayUsageMobile),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = BentoTextDark
                        )
                    }
                }
            }

            // Bento Box 4: Security Access Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(BentoSoftLavenderBg)
                    .border(BorderStroke(1.dp, BentoBorderLight), RoundedCornerShape(24.dp))
                    .clickable {
                        executeWithPinVerification { showSecurityMenuDialog = true }
                    }
                    .testTag("security_button")
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BentoAccentPurple),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Security lock",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "PIN Protection",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoTextDark
                            )
                            Text(
                                text = if (savedPinCode.isEmpty()) "Tap to set passcode" else "Active for all limit changes",
                                fontSize = 11.sp,
                                color = BentoTextDark.copy(alpha = 0.6f)
                            )
                        }
                    }

                    Text(
                        text = "CONFIG",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = BentoAccentPurple
                    )
                }
            }

            // Bento Warning Status Explanation Box
            Box(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                SafeStatusNote(isBlocked = isVpnBlockingState, isVpnActive = isVpnActiveState)
            }
        }

        // Bento Bottom Control Sheet: Dynamic limit changer directly within the core dashboard UI
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .testTag("limit_card"),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Adjust Daily Limit",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoTextDark
                    )
                    Text(
                        text = "RESETS AT MIDNIGHT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoTextDark.copy(alpha = 0.5f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Amount Numeric Input Field Block
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BentoSoftLavenderBg)
                            .drawBehind {
                                val strokeWidth = 2.dp.toPx()
                                val y = size.height - strokeWidth / 2
                                drawLine(
                                    color = BentoAccentPurple,
                                    start = androidx.compose.ui.geometry.Offset(0f, y),
                                    end = androidx.compose.ui.geometry.Offset(size.width, y),
                                    strokeWidth = strokeWidth
                                )
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Column {
                            Text(
                                text = "AMOUNT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoAccentPurple
                            )
                            
                            // Amount text input
                            TextField(
                                value = inputAmount,
                                onValueChange = { inputAmount = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("val_input"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = BentoTextDark,
                                    unfocusedTextColor = BentoTextDark
                                )
                            )
                        }
                    }

                    // Unit Selection Menu Block
                    var dropdownExpanded by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .width(100.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BentoSoftLavenderBg)
                            .drawBehind {
                                val strokeWidth = 2.dp.toPx()
                                val y = size.height - strokeWidth / 2
                                drawLine(
                                    color = BentoAccentPurple,
                                    start = androidx.compose.ui.geometry.Offset(0f, y),
                                    end = androidx.compose.ui.geometry.Offset(size.width, y),
                                    strokeWidth = strokeWidth
                                )
                            }
                            .clickable { dropdownExpanded = true }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Column {
                            Text(
                                text = "UNIT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoAccentPurple
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = inputUnit,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = BentoTextDark
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Dropdown indicators",
                                    tint = BentoAccentPurple,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.background(Color.White)
                        ) {
                            DropdownMenuItem(
                                text = { Text("MB", color = BentoTextDark) },
                                onClick = {
                                    inputUnit = "MB"
                                    dropdownExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("GB", color = BentoTextDark) },
                                onClick = {
                                    inputUnit = "GB"
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Unified "Save New Limit" buttons styled precisely in Bento purple
                Button(
                    onClick = {
                        executeWithPinVerification {
                            saveLimitAction()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("save_limit_btn"),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BentoAccentPurple,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Text(
                        text = "Save New Limit",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Animated Dialog Overlay: Numeric PIN Pad Lock Screen
        if (showPinPadDialog) {
            PinLockScreenDialog(
                correctPin = savedPinCode,
                onDismiss = {
                    showPinPadDialog = false
                    pendingActionAfterPin = null
                },
                onSuccess = {
                    showPinPadDialog = false
                    pendingActionAfterPin?.invoke()
                    pendingActionAfterPin = null
                }
            )
        }

        // Animated Dialog Overlay: Set Security/PIN Settings
        if (showSecurityMenuDialog) {
            SecuritySetupDialog(
                savedPin = savedPinCode,
                onDismiss = { showSecurityMenuDialog = false },
                onSavePin = { newPin ->
                    prefs.edit().putString("pin_code", newPin).apply()
                    showSecurityMenuDialog = false
                    updateLocalStates()
                    val msg = if (newPin.isEmpty()) "PIN lock removed" else "Passcode PIN security active"
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

/**
 * Beautiful dynamic warning note styled strictly under Material 3 Bento standards.
 */
@Composable
fun SafeStatusNote(isBlocked: Boolean, isVpnActive: Boolean) {
    val bentoWarningRed = Color(0xFFFDF2F2)
    val bentoWarningRedBorder = Color(0xFFFDE8E8)
    val bentoWarningRedText = Color(0xFF9B1C1C)

    val containerColor = if (isBlocked) bentoWarningRed else BentoSoftLavenderBg
    val borderColor = if (isBlocked) bentoWarningRedBorder else BentoBorderLight
    val textColor = if (isBlocked) bentoWarningRedText else BentoTextDark.copy(alpha = 0.7f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isBlocked) Icons.Default.Warning else Icons.Default.Info,
                contentDescription = "Status description notes",
                tint = if (isBlocked) bentoWarningRedText else BentoAccentPurple,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = if (isBlocked) {
                    "Today's data quota exceeded. Firewall rules are now active! All background and foreground internet packets are dropped silently."
                } else if (isVpnActive) {
                    "NetLimit VPN rules active. Daily counters automatically reset every day at midnight (12:00 AM) to restore connection safely."
                } else {
                    "Shield is offline. Traffic monitoring is disabled and no firewall rule constraints are currently being enforced. Activates on start."
                },
                fontSize = 11.sp,
                color = textColor,
                lineHeight = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Custom light bento-themed numeric PIN lock dialog.
 */
@Composable
fun PinLockScreenDialog(
    correctPin: String,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    var inputCode by remember { mutableStateOf("") }
    var isFailedAttempt by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(BentoLightBg)
                .clickable(enabled = false) { }, // Consume outer taps
            color = BentoLightBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Block
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 48.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(BentoUsageCardBg, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Secured configuration",
                            tint = BentoAccentPurple,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Enter Lock Screen PIN",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoTextDark
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Input 4-digit PIN lock code to authorize limit modification",
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        color = BentoTextDark.copy(alpha = 0.5f)
                    )
                }

                // Passcode Display Dot Progress Row
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 1..4) {
                            val isActive = inputCode.length >= i
                            val dotColor = if (isFailedAttempt) Color(0xFFEF4444) else if (isActive) BentoAccentPurple else BentoBorderGray
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .background(dotColor, CircleShape)
                            )
                        }
                    }

                    if (isFailedAttempt) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Incorrect Lock PIN. Try Again.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFEF4444)
                        )
                    }
                }

                // Tactile Numerical Grid Overlay
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val keyRows = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "⌫")
                    )

                    for (row in keyRows) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            for (key in row) {
                                KeypadButton(
                                    label = key,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        isFailedAttempt = false
                                        when (key) {
                                            "C" -> inputCode = ""
                                            "⌫" -> {
                                                if (inputCode.isNotEmpty()) {
                                                    inputCode = inputCode.dropLast(1)
                                                }
                                            }
                                            else -> {
                                                if (inputCode.length < 4) {
                                                    inputCode += key
                                                    // Trigger Verification
                                                    if (inputCode.length == 4) {
                                                        if (inputCode == correctPin) {
                                                            onSuccess()
                                                        } else {
                                                            isFailedAttempt = true
                                                            inputCode = ""
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "CANCEL AUTHORIZATION", 
                            color = BentoAccentPurple, 
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KeypadButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .aspectRatio(1.6f)
            .clip(RoundedCornerShape(16.dp))
            .background(BentoSoftLavenderBg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = BentoTextDark
        )
    }
}

/**
 * Configure Security Passcode / Lock Screen PIN.
 */
@Composable
fun SecuritySetupDialog(
    savedPin: String,
    onDismiss: () -> Unit,
    onSavePin: (String) -> Unit
) {
    var pinValue by remember { mutableStateOf(savedPin) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .testTag("security_setup_dialog"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = BentoLightBg),
            border = BorderStroke(1.dp, BentoBorderLight)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Passcode security lock configuration",
                    tint = BentoAccentPurple,
                    modifier = Modifier.size(40.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Security Protection PIN",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextDark
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Add a 4-digit numeric lock to restrict changing constraints and limits",
                    fontSize = 12.sp,
                    color = BentoTextDark.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = pinValue,
                    onValueChange = { pinValue = it.filter { c -> c.isDigit() }.take(4) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pin_input_field"),
                    label = { Text("4-Digit Numerical PIN") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoAccentPurple,
                        unfocusedBorderColor = BentoBorderGray,
                        focusedLabelColor = BentoAccentPurple,
                        unfocusedLabelColor = BentoTextDark.copy(alpha = 0.5f),
                        focusedTextColor = BentoTextDark,
                        unfocusedTextColor = BentoTextDark
                    ),
                    placeholder = { Text("None - Tap confirm to remove PIN", color = BentoTextDark.copy(alpha = 0.3f)) }
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(text = "CANCEL", color = BentoTextDark.copy(alpha = 0.6f))
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Button(
                        onClick = {
                            if (pinValue.isNotEmpty() && pinValue.length != 4) {
                                // Must be 4 digits
                            } else {
                                onSavePin(pinValue)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BentoAccentPurple),
                        enabled = pinValue.isEmpty() || pinValue.length == 4,
                        modifier = Modifier.testTag("save_security_btn")
                    ) {
                        Text(text = "CONFIRM SET", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Start/Update intents. Helper method to trigger service commands manually.
 */
fun triggerServiceIntent(context: Context, action: String) {
    val serviceIntent = Intent(context, MyVpnService::class.java).apply {
        this.action = action
    }
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Could not trigger firewall service: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Format bytes efficiently to MB / GB format strings
 */
fun formatBytes(bytes: Long): String {
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024

    return when {
        bytes >= gb -> String.format(Locale.getDefault(), "%.2f GB", bytes / gb)
        bytes >= mb -> String.format(Locale.getDefault(), "%.1f MB", bytes / mb)
        bytes >= kb -> String.format(Locale.getDefault(), "%.0f KB", bytes / kb)
        else -> "$bytes B"
    }
}
