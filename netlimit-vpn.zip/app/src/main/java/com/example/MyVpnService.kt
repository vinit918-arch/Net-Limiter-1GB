package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.TrafficStats
import android.net.VpnService
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MyVpnService : VpnService() {

    private val binder = VpnBinder()
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var monitorJob: Job? = null
    private var blockerThread: Thread? = null
    private var vpnInterface: ParcelFileDescriptor? = null

    private lateinit var prefs: SharedPreferences

    companion object {
        const val TAG = "NetLimitVpnService"
        const val NOTIFICATION_CHANNEL_ID = "netlimit_monitor_channel"
        const val NOTIFICATION_ID = 2026

        // Intent actions
        const val ACTION_START = "com.example.action.START"
        const val ACTION_STOP = "com.example.action.STOP"
        const val ACTION_REVALUATE = "com.example.action.REVALUATE"

        var isServiceRunning = false
            private set

        var isVpnBlocking = false
            private set
    }

    inner class VpnBinder : Binder() {
        fun getService(): MyVpnService = this@MyVpnService
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (intent != null && SERVICE_INTERFACE == intent.action) {
            return super.onBind(intent)
        }
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("netlimit_prefs", Context.MODE_PRIVATE)
        isServiceRunning = true
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            } else {
                0
            }
            startForeground(NOTIFICATION_ID, getServiceNotification("Monitoring network traffic...", false), fgsType)
        } else {
            startForeground(NOTIFICATION_ID, getServiceNotification("Monitoring network traffic...", false))
        }
        startDataMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        Log.d(TAG, "onStartCommand action: $action")

        when (action) {
            ACTION_START -> {
                revaluateTrafficAndBlockState()
            }
            ACTION_STOP -> {
                stopSelfAndRelease()
                return START_NOT_STICKY
            }
            ACTION_REVALUATE -> {
                revaluateTrafficAndBlockState()
            }
        }
        return START_STICKY
    }

    /**
     * Periodically tracks TrafficStats (Delta) every 3 seconds,
     * checks for midnight resets, and triggers firewall blocking if limit is met.
     */
    private fun startDataMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            // Save initial base system traffic counters
            initializeTrafficStatsBaseline()

            while (isActive) {
                try {
                    delay(3000)
                    checkMidnightReset()
                    accumulateTrafficStatsDeltas()
                    revaluateTrafficAndBlockState()
                } catch (e: CancellationException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Error in data monitoring loop: ${e.message}", e)
                }
            }
        }
    }

    private fun initializeTrafficStatsBaseline() {
        val systemTotalRx = TrafficStats.getTotalRxBytes()
        val systemTotalTx = TrafficStats.getTotalTxBytes()
        val systemMobileRx = TrafficStats.getMobileRxBytes()
        val systemMobileTx = TrafficStats.getMobileTxBytes()

        val currentTotal = if (systemTotalRx != TrafficStats.UNSUPPORTED.toLong()) systemTotalRx + systemTotalTx else 0L
        val currentMobile = if (systemMobileRx != TrafficStats.UNSUPPORTED.toLong()) systemMobileRx + systemMobileTx else 0L

        val lastSystemTotal = prefs.getLong("last_system_total", -1L)
        if (lastSystemTotal == -1L) {
            prefs.edit()
                .putLong("last_system_total", currentTotal)
                .putLong("last_system_mobile", currentMobile)
                .apply()
        }
    }

    private fun accumulateTrafficStatsDeltas() {
        val systemTotalRx = TrafficStats.getTotalRxBytes()
        val systemTotalTx = TrafficStats.getTotalTxBytes()
        val systemMobileRx = TrafficStats.getMobileRxBytes()
        val systemMobileTx = TrafficStats.getMobileTxBytes()

        val currentTotal = if (systemTotalRx != TrafficStats.UNSUPPORTED.toLong()) systemTotalRx + systemTotalTx else 0L
        val currentMobile = if (systemMobileRx != TrafficStats.UNSUPPORTED.toLong()) systemMobileRx + systemMobileTx else 0L

        var lastSystemTotal = prefs.getLong("last_system_total", currentTotal)
        var lastSystemMobile = prefs.getLong("last_system_mobile", currentMobile)

        var deltaTotal = 0L
        var deltaMobile = 0L

        if (currentTotal < lastSystemTotal) {
            // Reboot detected! Value reset to 0. Delta is just the new counter.
            deltaTotal = currentTotal
            deltaMobile = currentMobile
        } else {
            deltaTotal = currentTotal - lastSystemTotal
            deltaMobile = if (currentMobile >= lastSystemMobile) currentMobile - lastSystemMobile else currentMobile
        }

        val todayUsageTotal = prefs.getLong("today_usage_total", 0L)
        val todayUsageMobile = prefs.getLong("today_usage_mobile", 0L)

        prefs.edit()
            .putLong("today_usage_total", todayUsageTotal + deltaTotal)
            .putLong("today_usage_mobile", todayUsageMobile + deltaMobile)
            .putLong("last_system_total", currentTotal)
            .putLong("last_system_mobile", currentMobile)
            .apply()

        Log.d(TAG, "Accumulated delta: Total = +$deltaTotal bytes, Mobile = +$deltaMobile bytes")
    }

    private fun checkMidnightReset() {
        val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())
        val savedDateStr = prefs.getString("last_recorded_date", "") ?: ""

        if (savedDateStr.isNotEmpty() && savedDateStr != todayStr) {
            Log.d(TAG, "Midnight reached! Resetting data counter from $savedDateStr to $todayStr")
            prefs.edit()
                .putLong("today_usage_total", 0L)
                .putLong("today_usage_mobile", 0L)
                .putString("last_recorded_date", todayStr)
                .apply()

            // Flash a notification that counters were reset
            updateNotification("New day started. Network and firewall statistics reset.", false)
        } else if (savedDateStr.isEmpty()) {
            prefs.edit().putString("last_recorded_date", todayStr).apply()
        }
    }

    /**
     * Checks if current usage has reached the user-defined limit.
     * Starts the local VPN blockage if exceeded, or stops it if under control.
     */
    @Synchronized
    private fun revaluateTrafficAndBlockState() {
        val limitBytes = prefs.getLong("daily_limit_bytes", 1024L * 1024 * 1024) // default 1GB
        val currentTodayBytes = prefs.getLong("today_usage_total", 0L)
        val firewallEnabled = prefs.getBoolean("firewall_enabled", true)

        Log.d(TAG, "Revaluating status: Usage = $currentTodayBytes / Limit = $limitBytes | Block Enabled = $firewallEnabled")

        if (firewallEnabled && currentTodayBytes >= limitBytes) {
            if (!isVpnBlocking) {
                Log.w(TAG, "Data limit reached! Engaging local VPN silent firewall packet sink.")
                establishVpnAndBlock()
            } else {
                // Already blocking, keep notification accurate
                val percentProgress = if (limitBytes > 0) (currentTodayBytes * 100 / limitBytes).toInt() else 100
                updateNotification("LIMIT EXCEEDED ($percentProgress%). Silent firewall blocking all internet traffic.", true)
            }
        } else {
            if (isVpnBlocking) {
                Log.i(TAG, "Data usage is within limits. Releasing local VPN packet firewall.")
                releaseVpn()
            } else {
                val formattedLimit = formatDataSize(limitBytes)
                val formattedUsage = formatDataSize(currentTodayBytes)
                updateNotification("Firewall Active: $formattedUsage of $formattedLimit used.", false)
            }
        }
    }

    /**
     * Establishes the VPN TUN Interface containing standard internet routes (0.0.0.0/0, ::/0).
     * It reads packets inside a background thread but drops them entirely, creating a 100% silent,
     * system-level packet drop firewall block across all apps without triggering any warnings.
     */
    private fun establishVpnAndBlock() {
        try {
            if (vpnInterface != null) {
                return
            }

            val builder = Builder()
            builder.setSession("NetLimit Firewall Block")
                .setMtu(1500)
                // Add secure dummy credentials to make the virtual loop interface register in Android
                .addAddress("10.8.0.1", 24)
                .addRoute("0.0.0.0", 0)  // Capture all IPv4 traffic
                .addRoute("::", 0)       // Capture all IPv6 traffic
                .setBlocking(true)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(true)
            }

            vpnInterface = builder.establish()
            isVpnBlocking = true

            if (vpnInterface == null) {
                Log.e(TAG, "Failed to establish VPN interface. Received null descriptor.")
                isVpnBlocking = false
                return
            }

            // Launch a dedicated background packet reader thread that receives and drops all data packets
            startPacketSinker()

            val limitBytes = prefs.getLong("daily_limit_bytes", 1024L * 1024 * 1024)
            val currentTodayBytes = prefs.getLong("today_usage_total", 0L)
            val percentProgress = if (limitBytes > 0) (currentTodayBytes * 100 / limitBytes).toInt() else 100
            updateNotification("LIMIT EXCEEDED ($percentProgress%). Silent firewall blocking all internet traffic.", true)

            // Broadcast change to UI
            sendBroadcast(Intent("com.example.action.FIREWALL_STATE_CHANGED"))

        } catch (e: Exception) {
            Log.e(TAG, "Could not establish local VPN: ${e.message}", e)
            isVpnBlocking = false
        }
    }

    private fun startPacketSinker() {
        blockerThread?.interrupt()
        blockerThread = Thread({
            val fd = vpnInterface?.fileDescriptor ?: return@Thread
            val inputStream = FileInputStream(fd)
            val packetBuffer = ByteArray(32768)

            Log.i(TAG, "Packet Sinker Thread started. Dropping all incoming intercepted packets.")

            while (!Thread.currentThread().isInterrupted && isVpnBlocking) {
                try {
                    // Read packets from the virtual TUN interface.
                    // Doing nothing with the buffer silently sinks/drops them!
                    val bytesRead = inputStream.read(packetBuffer)
                    if (bytesRead <= 0) {
                        Thread.sleep(10)
                    }
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    if (!isVpnBlocking) break
                    Log.e(TAG, "Crash or exception in Packet Sinker Thread: ${e.message}")
                    try { Thread.sleep(100) } catch (ie: InterruptedException) { break }
                }
            }
            Log.i(TAG, "Packet Sinker Thread stopped.")
        }, "NetLimitPacketSinker")
        blockerThread?.start()
    }

    @Synchronized
    private fun releaseVpn() {
        isVpnBlocking = false
        blockerThread?.interrupt()
        blockerThread = null

        try {
            vpnInterface?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Exception while closing VPN virtual file descriptor", e)
        }
        vpnInterface = null

        // Update notification
        val limitBytes = prefs.getLong("daily_limit_bytes", 1024L * 1024 * 1024)
        val currentTodayBytes = prefs.getLong("today_usage_total", 0L)
        val formattedLimit = formatDataSize(limitBytes)
        val formattedUsage = formatDataSize(currentTodayBytes)
        updateNotification("Firewall Active: $formattedUsage of $formattedLimit used.", false)

        // Broadcast change to UI
        sendBroadcast(Intent("com.example.action.FIREWALL_STATE_CHANGED"))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "NetLimit Firewall Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors daily network data usage and implements silent lock firewall rules."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun getServiceNotification(contentText: String, blocked: Boolean): Notification {
        val titleText = if (blocked) "⚠️ Internet Connection Blocked" else "🛡️ NetLimit VPN Shield Active"
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(titleText)
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(contentText: String, blocked: Boolean) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, getServiceNotification(contentText, blocked))
    }

    private fun stopSelfAndRelease() {
        Log.i(TAG, "Stopping NetLimit VPN Background Service and clearing firewall blocks.")
        releaseVpn()
        isServiceRunning = false
        monitorJob?.cancel()
        serviceJob.cancel()
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        stopSelfAndRelease()
        super.onDestroy()
    }

    private fun formatDataSize(bytes: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024

        return when {
            bytes >= gb -> String.format(Locale.getDefault(), "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.getDefault(), "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.getDefault(), "%.0f KB", bytes / kb)
            else -> "$bytes Bytes"
        }
    }
}
