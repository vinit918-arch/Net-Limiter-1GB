package com.example.shizuku

import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuShellExecutor {
    private const val TAG = "ShizukuShellExecutor"

    // Check if the Shizuku service is running and accessible
    fun isAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku ping binder failed", e)
            false
        }
    }

    // Check if this application has been granted the Shizuku permission
    fun hasPermission(): Boolean {
        return try {
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku check permission failed", e)
            false
        }
    }

    // Request Shizuku permission from the user
    fun requestPermission(requestCode: Int) {
        try {
            if (!Shizuku.isPreV11()) {
                Shizuku.requestPermission(requestCode)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku request permission failed", e)
        }
    }

    // Register a permission listener
    fun registerListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.addRequestPermissionResultListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Register listener failed", e)
        }
    }

    // Unregister a permission listener
    fun unregisterListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.removeRequestPermissionResultListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Unregister listener failed", e)
        }
    }

    // Execute an ADB shell command asynchronously in the remote shell
    suspend fun executeCommand(command: String): ExecutionResult = withContext(Dispatchers.IO) {
        if (!isAvailable()) {
            return@withContext ExecutionResult(
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku service is not running or not available."
            )
        }

        if (!hasPermission()) {
            return@withContext ExecutionResult(
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku permission is not granted."
            )
        }

        try {
            // Start a remote process via Shizuku. We invoke "sh" as our remote shell executor.
            val process = Shizuku.newProcess(arrayOf("sh"), null, null)
            val os = process.outputStream
            val inputStream = process.inputStream
            val errStream = process.errorStream

            // Send command, then exit so that process.waitFor() finishes properly
            os.write(("$command\nexit\n").toByteArray())
            os.flush()

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            // Read stdout in background thread
            val stdoutReader = BufferedReader(InputStreamReader(inputStream))
            val stderrReader = BufferedReader(InputStreamReader(errStream))

            var line: String?
            while (stdoutReader.readLine().also { line = it } != null) {
                stdoutBuilder.append(line).append("\n")
            }

            var errLine: String?
            while (stderrReader.readLine().also { errLine = it } != null) {
                stderrBuilder.append(errLine).append("\n")
            }

            val exitCode = process.waitFor()

            os.close()
            inputStream.close()
            errStream.close()

            ExecutionResult(
                exitCode = exitCode,
                stdout = stdoutBuilder.toString().trim(),
                stderr = stderrBuilder.toString().trim()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error running command: $command", e)
            ExecutionResult(
                exitCode = -2,
                stdout = "",
                stderr = e.message ?: "Unknown execution error"
            )
        }
    }

    data class ExecutionResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    ) {
        val isSuccess: Boolean get() = exitCode == 0
    }
}
