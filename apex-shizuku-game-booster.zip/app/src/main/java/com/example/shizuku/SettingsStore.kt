package com.example.shizuku

import android.content.Context
import android.content.SharedPreferences

object SettingsStore {
    private const val PREFS_NAME = "game_booster_prefs"
    private const val KEY_GAMES = "game_packages"
    private const val KEY_CUSTOM_COMMANDS = "custom_commands"
    
    // Performance Engine Settings
    const val KEY_PERF_MODE = "perf_power_mode"
    const val KEY_DISABLE_POWER_SAVING = "disable_power_saving"
    const val KEY_FORCE_HW_OVERLAYS = "force_hw_overlays"
    const val KEY_DISABLE_TELEMETRY = "disable_telemetry"
    
    // RAM Module Settings
    const val KEY_STOP_3RD_PARTY = "ram_stop_3rd_party"
    const val KEY_STOP_RECOMMENDED = "ram_stop_recommended"
    const val KEY_STOP_ALL_BACKGROUND = "ram_stop_all_background"
    const val KEY_STOP_HIDDEN_SERVICES = "ram_stop_hidden_services"

    // Storage Sweep Last Run
    const val KEY_LAST_SWEEP_DATE = "last_sweep_date"

    // Display Modifiers
    const val KEY_DOWNSCALE_PRESET = "downscale_preset" // "none", "720p", "1080p"
    const val KEY_CUSTOM_RESOLUTION = "custom_resolution" // "1080x2400"
    const val KEY_CUSTOM_DPI = "custom_dpi" // "360"
    const val KEY_HWUI_RENDERER = "hwui_renderer" // "Default", "SkiaGL", "SkiaVK"
    const val KEY_GRAPHICS_DRIVER = "graphics_driver" // "Default", "Game Driver", "System"

    // Externals & Modifiers
    const val KEY_ANIMATION_MASTER = "animation_master" // Boolean (true = 0x, false = 1x)
    const val KEY_AD_BLOCKER = "ad_blocker"
    const val KEY_GOOGLE_FREEZE = "google_freeze"
    const val KEY_LOG_KILLER = "log_killer"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // Games list (Package names)
    fun getAddedGames(context: Context): Set<String> {
        return getPrefs(context).getStringSet(KEY_GAMES, setOf(
            "com.pubg.imobile",
            "com.tencent.ig",
            "com.dts.freefireth",
            "com.mobile.legends",
            "com.epicgames.fortnite"
        )) ?: emptySet()
    }

    fun addGame(context: Context, packageName: String) {
        val games = getAddedGames(context).toMutableSet()
        games.add(packageName)
        getPrefs(context).edit().putStringSet(KEY_GAMES, games).apply()
    }

    fun removeGame(context: Context, packageName: String) {
        val games = getAddedGames(context).toMutableSet()
        games.remove(packageName)
        getPrefs(context).edit().putStringSet(KEY_GAMES, games).apply()
    }

    // Saved Commands (For advanced terminal)
    fun getSavedCommands(context: Context): List<String> {
        val savedStr = getPrefs(context).getString(KEY_CUSTOM_COMMANDS, "") ?: ""
        if (savedStr.isEmpty()) return listOf(
            "dumpsys battery reset",
            "dumpsys battery set level 100",
            "device_config put latency_tracker enabled false"
        )
        return savedStr.split("|||").filter { it.isNotEmpty() }
    }

    fun saveCommand(context: Context, command: String) {
        val commands = getSavedCommands(context).toMutableList()
        if (!commands.contains(command)) {
            commands.add(command)
            getPrefs(context).edit().putString(KEY_CUSTOM_COMMANDS, commands.joinToString("|||")).apply()
        }
    }

    fun removeSavedCommand(context: Context, command: String) {
        val commands = getSavedCommands(context).toMutableList()
        commands.remove(command)
        getPrefs(context).edit().putString(KEY_CUSTOM_COMMANDS, commands.joinToString("|||")).apply()
    }

    // Generic SharedPreferences get/set functions
    fun getBoolean(context: Context, key: String, default: Boolean = false): Boolean {
        return getPrefs(context).getBoolean(key, default)
    }

    fun setBoolean(context: Context, key: String, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).apply()
    }

    fun getString(context: Context, key: String, default: String = ""): String {
        return getPrefs(context).getString(key, default) ?: default
    }

    fun setString(context: Context, key: String, value: String) {
        getPrefs(context).edit().putString(key, value).apply()
    }
}
