package com.example

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.service.GameAutomationService
import com.example.shizuku.SettingsStore
import com.example.shizuku.ShizukuShellExecutor
import com.example.ui.theme.MyApplicationTheme
import rikka.shizuku.Shizuku
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    private val SHIZUKU_REQUEST_CODE = 1001

    // Shizuku permission result callback
    private val requestPermissionResultListener = object : Shizuku.OnRequestPermissionResultListener {
        override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                lifecycleScope.launch(Dispatchers.Main) {
                    shizukuPermissionState = granted
                    Toast.makeText(
                        this@MainActivity,
                        if (granted) "Shizuku Permission Granted!" else "Shizuku Permission Denied.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // Compose observable state variables
    private var shizukuInstalledState by mutableStateOf(false)
    private var shizukuPermissionState by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check initial state
        updateShizukuState()

        // Listen for Shizuku permission events
        try {
            ShizukuShellExecutor.registerListener(requestPermissionResultListener)
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to register Shizuku listener", e)
        }

        setContent {
            MyApplicationTheme {
                MainScreen(
                    shizukuInstalled = shizukuInstalledState,
                    shizukuPermission = shizukuPermissionState,
                    onRequestPermission = {
                        ShizukuShellExecutor.requestPermission(SHIZUKU_REQUEST_CODE)
                    },
                    onRefreshState = {
                        updateShizukuState()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateShizukuState()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            ShizukuShellExecutor.unregisterListener(requestPermissionResultListener)
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to unregister Shizuku listener", e)
        }
    }

    private fun updateShizukuState() {
        shizukuInstalledState = ShizukuShellExecutor.isAvailable()
        shizukuPermissionState = ShizukuShellExecutor.hasPermission()
    }
}

// Data structures for system details
data class AppEntry(val label: String, val packageName: String)
data class MemoryDetails(val total: String, val used: String, val available: String, val percentage: Int)
data class StorageDetails(val total: String, val used: String, val available: String, val percentage: Int)

// Helper functions for reading dynamic system metrics
fun getMemoryMetrics(context: Context): MemoryDetails {
    return try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalGb = memInfo.totalMem.toDouble() / (1024 * 1024 * 1024)
        val availGb = memInfo.availMem.toDouble() / (1024 * 1024 * 1024)
        val usedGb = totalGb - availGb
        val pct = ((usedGb / totalGb) * 100).toInt()
        MemoryDetails(
            total = String.format("%.2f GB", totalGb),
            used = String.format("%.2f GB", usedGb),
            available = String.format("%.2f GB", availGb),
            percentage = pct
        )
    } catch (e: Exception) {
        MemoryDetails("8.0 GB", "4.0 GB", "4.0 GB", 50)
    }
}

fun getStorageMetrics(): StorageDetails {
    return try {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockS = stat.blockSizeLong
        val totalB = stat.blockCountLong
        val availB = stat.availableBlocksLong
        val totalGb = (totalB * blockS).toDouble() / (1024 * 1024 * 1024)
        val availGb = (availB * blockS).toDouble() / (1024 * 1024 * 1024)
        val usedGb = totalGb - availGb
        val pct = ((usedGb / totalGb) * 100).toInt()
        StorageDetails(
            total = String.format("%.1f GB", totalGb),
            used = String.format("%.1f GB", usedGb),
            available = String.format("%.1f GB", availGb),
            percentage = pct
        )
    } catch (e: Exception) {
        StorageDetails("128 GB", "64 GB", "64 GB", 50)
    }
}

// Queries all device launcher packages
fun queryInstalledLauncherApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }
    val resolveList = pm.queryIntentActivities(intent, 0)
    return resolveList.map {
        AppEntry(
            label = it.loadLabel(pm).toString(),
            packageName = it.activityInfo.packageName
        )
    }.distinctBy { it.packageName }.sortedBy { it.label }
}

enum class ActiveScreen {
    Home, Settings
}

@Composable
fun MainScreen(
    shizukuInstalled: Boolean,
    shizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    onRefreshState: () -> Unit
) {
    val context = LocalContext.current
    var activeScreen by remember { mutableStateOf(ActiveScreen.Home) }
    var addedGamesList by remember { mutableStateOf(SettingsStore.getAddedGames(context).toList()) }
    var showAppPickerDialog by remember { mutableStateOf(false) }

    // Optimization status triggers
    var isOptimizingState by remember { mutableStateOf(false) }
    var optimizationLogOutput by remember { mutableStateOf("") }

    // Read initial settings options to show status rings
    val isPerfActive = SettingsStore.getBoolean(context, SettingsStore.KEY_PERF_MODE)
    val isRamActive = SettingsStore.getBoolean(context, SettingsStore.KEY_STOP_3RD_PARTY)
    val isScaleActive = SettingsStore.getBoolean(context, SettingsStore.KEY_ANIMATION_MASTER)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            AnimatedContent(
                targetState = activeScreen,
                transitionSpec = {
                    slideInHorizontally { width -> if (targetState == ActiveScreen.Settings) width else -width } + fadeIn() togetherWith
                            slideOutHorizontally { width -> if (targetState == ActiveScreen.Settings) -width else width } + fadeOut()
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    ActiveScreen.Home -> {
                        HomeScreen(
                            shizukuInstalled = shizukuInstalled,
                            shizukuPermission = shizukuPermission,
                            addedGames = addedGamesList,
                            isOptimizing = isOptimizingState,
                            optimizationLog = optimizationLogOutput,
                            isPerfActive = isPerfActive,
                            isRamActive = isRamActive,
                            isScaleActive = isScaleActive,
                            onOpenSettings = { activeScreen = ActiveScreen.Settings },
                            onAddGameClick = { showAppPickerDialog = true },
                            onRemoveGame = { pkg ->
                                SettingsStore.removeGame(context, pkg)
                                addedGamesList = SettingsStore.getAddedGames(context).toList()
                                Toast.makeText(context, "Removed from list", Toast.LENGTH_SHORT).show()
                            },
                            onTriggerOptimization = {
                                isOptimizingState = true
                                optimizationLogOutput = "Initializing optimizations...\n"
                                CoroutineScope(Dispatchers.Main).launch {
                                    delay(500)
                                    optimizationLogOutput += "Running profiles...\n"
                                    
                                    val commands = mutableListOf<String>()
                                    if (SettingsStore.getBoolean(context, SettingsStore.KEY_PERF_MODE)) {
                                        commands.add("cmd power set-mode 2")
                                    }
                                    if (SettingsStore.getBoolean(context, SettingsStore.KEY_ANIMATION_MASTER)) {
                                        commands.add("settings put global window_animation_scale 0.0")
                                    }
                                    commands.add("am trim-caches 20")
                                    
                                    if (shizukuInstalled && shizukuPermission && commands.isNotEmpty()) {
                                        val result = ShizukuShellExecutor.executeCommand(commands.joinToString("\n"))
                                        optimizationLogOutput += "Exit Code: ${result.exitCode}\n"
                                        if (result.stdout.isNotEmpty()) optimizationLogOutput += "${result.stdout}\n"
                                        if (result.stderr.isNotEmpty()) optimizationLogOutput += "Err: ${result.stderr}\n"
                                    } else {
                                        optimizationLogOutput += "Done (No active triggers or permission missing)\n"
                                    }
                                    delay(1000)
                                    isOptimizingState = false
                                    Toast.makeText(context, "Optimization Complete!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onRequestShizukuPermission = onRequestPermission,
                            onRefreshStats = onRefreshState
                        )
                    }
                    ActiveScreen.Settings -> {
                        SettingsPanelScreen(
                            shizukuInstalled = shizukuInstalled,
                            shizukuPermission = shizukuPermission,
                            onBackToHome = {
                                activeScreen = ActiveScreen.Home
                            }
                        )
                    }
                }
            }

            // Game package Picker dialog overlay
            if (showAppPickerDialog) {
                AppPickerDialog(
                    onDismiss = { showAppPickerDialog = false },
                    onAppSelected = { entry ->
                        SettingsStore.addGame(context, entry.packageName)
                        addedGamesList = SettingsStore.getAddedGames(context).toList()
                        showAppPickerDialog = false
                        Toast.makeText(context, "Added ${entry.label} to games list", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    shizukuInstalled: Boolean,
    shizukuPermission: Boolean,
    addedGames: List<String>,
    isOptimizing: Boolean,
    optimizationLog: String,
    isPerfActive: Boolean,
    isRamActive: Boolean,
    isScaleActive: Boolean,
    onOpenSettings: () -> Unit,
    onAddGameClick: () -> Unit,
    onRemoveGame: (String) -> Unit,
    onTriggerOptimization: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onRefreshStats: () -> Unit
) {
    val context = LocalContext.current

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- LEFT PANEL: Added Games Carousel List ---
        Column(
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                .border(
                    BorderStroke(1.dp, Color(0xFF1E2638)),
                    shape = RoundedCornerShape(topStart = 0.dp, bottomStart = 0.dp)
                )
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TARGET GAMES",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                IconButton(
                    onClick = onRefreshStats,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Stat",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Games list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (addedGames.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No games added.\nClick [+] to add your custom games.",
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(addedGames) { pkg ->
                        GameItemCard(packageName = pkg, onRemove = { onRemoveGame(pkg) })
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Float action add [+] package picker launcher
            Button(
                onClick = onAddGameClick,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_game_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add game package picker button",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ADD GAME",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // --- CENTER & RIGHT AREA: Center Canvas & Quick Indicators ---
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header bar containing Title and [⚙️] Settings Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (shizukuInstalled && shizukuPermission) Color(0xFF00FF66) else Color(0xFFEF4444))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SWIFTBOOSTER ENGINE",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "Non-Root System Level ADB Shell Optimizer",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Shizuku connection info
                    ShizukuIndicator(
                        installed = shizukuInstalled,
                        hasPermission = shizukuPermission,
                        onRequestPermission = onRequestShizukuPermission
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("settings_button")
                            .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Open Settings Panel Button",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Center Dynamic Optimization Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isOptimizing) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(72.dp),
                            strokeWidth = 6.dp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = optimizationLog,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        // Stunning Optimize button with green glow
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .shadow(24.dp, shape = CircleShape, ambientColor = Color(0xFF00FF66), spotColor = Color(0xFF00FF66))
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF112217),
                                            Color(0xFF0A0D14)
                                        )
                                    ),
                                    shape = CircleShape
                                )
                                .border(BorderStroke(2.dp, MaterialTheme.colorScheme.primary), shape = CircleShape)
                                .clickable { onTriggerOptimization() }
                                .testTag("optimize_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Optimize bolt action icon",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "OPTIMIZE",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Footer dashboard statuses
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatusIndicatorCard(
                    title = "PERFORMANCE MODE",
                    isActive = isPerfActive,
                    icon = Icons.Default.Speed,
                    modifier = Modifier.weight(1f)
                )
                StatusIndicatorCard(
                    title = "RAM RESTRICTOR",
                    isActive = isRamActive,
                    icon = Icons.Default.Memory,
                    modifier = Modifier.weight(1f)
                )
                StatusIndicatorCard(
                    title = "ANIMATION TWEAKS",
                    isActive = isScaleActive,
                    icon = Icons.Default.TrendingUp,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun GameItemCard(packageName: String, onRemove: () -> Unit) {
    // Attempt to extract short name for cleaner UI
    val shortName = packageName.substringAfterLast(".")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.secondary, shape = RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF2C394F), shape = RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFF141D29), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SportsEsports,
                    contentDescription = "Game controller icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = shortName.uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = packageName,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    fontSize = 8.sp,
                    maxLines = 1
                )
            }
        }
        IconButton(
            onClick = onRemove,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Remove Game Button",
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun ShizukuIndicator(
    installed: Boolean,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    Row(
        modifier = Modifier
            .background(Color(0xFF141D29), shape = RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF2C394F), shape = RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "SHIZUKU: ",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            fontFamily = FontFamily.Monospace
        )
        if (!installed) {
            Text(
                text = "NOT INSTALLED",
                fontSize = 9.sp,
                color = Color(0xFFEF4444),
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        } else if (!hasPermission) {
            Text(
                text = "REQUEST PERMISSION",
                fontSize = 9.sp,
                color = Color(0xFFFF9800),
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.clickable { onRequestPermission() }
            )
        } else {
            Text(
                text = "CONNECTED",
                fontSize = 9.sp,
                color = Color(0xFF00FF66),
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun StatusIndicatorCard(
    title: String,
    isActive: Boolean,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
            Text(
                text = if (isActive) "ACTIVE" else "READY",
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)
            )
        }
    }
}

// Dialog picker for launcher package configurations
@Composable
fun AppPickerDialog(
    onDismiss: () -> Unit,
    onAppSelected: (AppEntry) -> Unit
) {
    val context = LocalContext.current
    var appsList by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        appsList = queryInstalledLauncherApps(context)
    }

    val filteredApps = appsList.filter {
        it.label.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(420.dp)
                .height(280.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, Color(0xFF2C394F))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SELECT TARGET GAME",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search application package...", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color(0xFF2C394F)
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (filteredApps.isEmpty()) {
                        item {
                            Text(
                                text = "No matching apps found.",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(12.dp),
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    } else {
                        items(filteredApps) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onAppSelected(app) }
                                    .background(Color(0xFF141D29), shape = RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = app.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = app.packageName,
                                        fontSize = 8.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- DETAILED SETTINGS PANEL ---
@Composable
fun SettingsPanelScreen(
    shizukuInstalled: Boolean,
    shizukuPermission: Boolean,
    onBackToHome: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // 1. Performance Engine settings
    var isPerfMode by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_PERF_MODE)) }
    var isDisablePowerSaving by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_DISABLE_POWER_SAVING)) }
    var isForceHwOverlays by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_FORCE_HW_OVERLAYS)) }
    var isDisableTelemetry by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_DISABLE_TELEMETRY)) }

    // 2. RAM Restrictors
    var ramStop3rdParty by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_STOP_3RD_PARTY)) }
    var ramStopRecommended by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_STOP_RECOMMENDED)) }
    var ramStopAllBackground by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_STOP_ALL_BACKGROUND)) }
    var ramStopHiddenServices by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_STOP_HIDDEN_SERVICES)) }

    // Memory info
    var memDetails by remember { mutableStateOf(getMemoryMetrics(context)) }

    // Storage info
    var storageDetails by remember { mutableStateOf(getStorageMetrics()) }

    // 3. Display Tweaks
    var selectedPreset by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_DOWNSCALE_PRESET, "none")) }
    var customWidth by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_CUSTOM_RESOLUTION, "").substringBefore("x")) }
    var customHeight by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_CUSTOM_RESOLUTION, "").substringAfter("x", "")) }
    var customDpi by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_CUSTOM_DPI, "")) }
    var selectedHwui by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_HWUI_RENDERER, "Default")) }
    var selectedDriver by remember { mutableStateOf(SettingsStore.getString(context, SettingsStore.KEY_GRAPHICS_DRIVER, "Default")) }

    // 4. Externals
    var animationMaster by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_ANIMATION_MASTER)) }
    var isAdBlockerActive by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_AD_BLOCKER)) }
    var googleFreezeActive by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_GOOGLE_FREEZE)) }
    var logKillerActive by remember { mutableStateOf(SettingsStore.getBoolean(context, SettingsStore.KEY_LOG_KILLER)) }

    // 5. Terminal inputs
    var terminalInput by remember { mutableStateOf("") }
    var terminalOutput by remember { mutableStateOf("SwiftBooster Terminal Console v1.0. Ready.\n") }
    var savedCommandsList by remember { mutableStateOf(SettingsStore.getSavedCommands(context)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(12.dp)
    ) {
        // Settings title top-bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBackToHome,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back button to exit Settings Panel Screen",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ADVANCED OPTIMIZER SETTINGS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = {
                    // Fast update metrics
                    memDetails = getMemoryMetrics(context)
                    storageDetails = getStorageMetrics()
                    Toast.makeText(context, "Telemetry stats updated!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141D29)),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFF2C394F)),
                modifier = Modifier.height(30.dp)
            ) {
                Text(
                    text = "REFRESH ANALYTICS",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // --- LEFT COLUMN: Terminal and System Stats ---
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Interactive Shell Terminal Section (Absolutely at the top)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.4f)
                        .background(Color(0xFF0D1117), shape = RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = "LADB Console Icon",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SHIZUKU INTERACTIVE SHELL",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Terminal output scrolling screen
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.Black, shape = RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF232B3B), shape = RoundedCornerShape(6.dp))
                                .padding(6.dp)
                        ) {
                            val outScroll = rememberScrollState()
                            Text(
                                text = terminalOutput,
                                color = Color(0xFF00FF66),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(outScroll)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Terminal commands custom input row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = terminalInput,
                                onValueChange = { terminalInput = it },
                                placeholder = { Text("Enter shell script...", fontSize = 10.sp) },
                                modifier = Modifier.weight(1f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color(0xFF2C394F)
                                )
                            )

                            Button(
                                onClick = {
                                    if (terminalInput.trim().isEmpty()) return@Button
                                    terminalOutput += "\n$ ${terminalInput}\n"
                                    CoroutineScope(Dispatchers.Main).launch {
                                        val cmd = terminalInput.trim()
                                        terminalInput = ""
                                        val res = ShizukuShellExecutor.executeCommand(cmd)
                                        terminalOutput += if (res.stdout.isNotEmpty()) "${res.stdout}\n" else ""
                                        terminalOutput += if (res.stderr.isNotEmpty()) "Err: ${res.stderr}\n" else ""
                                        terminalOutput += "Exit code: ${res.exitCode}\n"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("RUN", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    if (terminalInput.trim().isNotEmpty()) {
                                        SettingsStore.saveCommand(context, terminalInput.trim())
                                        savedCommandsList = SettingsStore.getSavedCommands(context)
                                        Toast.makeText(context, "Command Saved!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF212936)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("SAVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        // Preserved Command Template Row
                        if (savedCommandsList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SAVED PRESETS:",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                savedCommandsList.take(3).forEach { cmd ->
                                    val displayLabel = if (cmd.length > 20) cmd.take(18) + ".." else cmd
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF141D29), shape = RoundedCornerShape(4.dp))
                                            .border(1.dp, Color(0xFF2C394F), shape = RoundedCornerShape(4.dp))
                                            .clickable { terminalInput = cmd }
                                            .padding(horizontal = 6.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = displayLabel,
                                            fontSize = 8.sp,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Dynamic Progress Indicators Row (RAM + Storage analytics)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.7f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // RAM status card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0D1117), shape = RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(10.dp))
                            .padding(8.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("RAM ANALYTICS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                                Text("${memDetails.percentage}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                            }
                            LinearProgressIndicator(
                                progress = { memDetails.percentage.toFloat() / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = Color(0xFF1F2937),
                            )
                            Text(
                                text = "Used: ${memDetails.used} / ${memDetails.total}",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Storage status card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0D1117), shape = RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(10.dp))
                            .padding(8.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("STORAGE CAPACITY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                                Text("${storageDetails.percentage}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                            }
                            LinearProgressIndicator(
                                progress = { storageDetails.percentage.toFloat() / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.tertiary,
                                trackColor = Color(0xFF1F2937),
                            )
                            Text(
                                text = "Used: ${storageDetails.used} / ${storageDetails.total}",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // --- RIGHT COLUMN: Config Options Grid ---
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Section 1: Performance Engine
                SettingsSectionContainer(title = "PERFORMANCE ENGINE PROFILE") {
                    SettingsSwitchRow(
                        title = "Overclock / Performance Mode",
                        desc = "Enforces thermal profiling & CPU/EGL clock settings",
                        checked = isPerfMode,
                        onCheckedChange = {
                            isPerfMode = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_PERF_MODE, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Disable Power Saving State",
                        desc = "Forcefully suspends Android Low-Power limitations",
                        checked = isDisablePowerSaving,
                        onCheckedChange = {
                            isDisablePowerSaving = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_DISABLE_POWER_SAVING, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Force Hardware Overlays",
                        desc = "Disables software overlays and triggers MSAA 4x rendering",
                        checked = isForceHwOverlays,
                        onCheckedChange = {
                            isForceHwOverlays = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_FORCE_HW_OVERLAYS, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Block Telemetry Systems",
                        desc = "Disables latency diagnostics and analytics polling",
                        checked = isDisableTelemetry,
                        onCheckedChange = {
                            isDisableTelemetry = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_DISABLE_TELEMETRY, it)
                        }
                    )
                }

                // Section 2: RAM Optimization Modules
                SettingsSectionContainer(title = "RAM OPTIMIZER SELECTIONS") {
                    SettingsSwitchRow(
                        title = "Restrict Third-Party Background Apps",
                        desc = "Forcefully kills non-system external package runtimes",
                        checked = ramStop3rdParty,
                        onCheckedChange = {
                            ramStop3rdParty = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_STOP_3RD_PARTY, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Continuous Trim Cache Levels",
                        desc = "Periodic memory trimming of recommendations",
                        checked = ramStopRecommended,
                        onCheckedChange = {
                            ramStopRecommended = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_STOP_RECOMMENDED, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Suspend Hidden Background Runtimes",
                        desc = "Trims inactive system apps to free critical RAM chunks",
                        checked = ramStopAllBackground,
                        onCheckedChange = {
                            ramStopAllBackground = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_STOP_ALL_BACKGROUND, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Stop Hidden Package Services",
                        desc = "Locks and suspends hidden developer tracking threads",
                        checked = ramStopHiddenServices,
                        onCheckedChange = {
                            ramStopHiddenServices = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_STOP_HIDDEN_SERVICES, it)
                        }
                    )
                }

                // Section 3: Storage Sweeper
                SettingsSectionContainer(title = "STORAGE CLEANING ENGINE") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Deep Sweep Cache Space", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Invokes clean-caches ADB script on device package runtimes", fontSize = 8.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                        }
                        Button(
                            onClick = {
                                CoroutineScope(Dispatchers.Main).launch {
                                    val result = ShizukuShellExecutor.executeCommand("pm trim-caches 99999999999999999")
                                    if (result.isSuccess) {
                                        Toast.makeText(context, "System Cache Trimmed Safely!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Trim complete (no system-wide cache cleared)", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("CLEAR CACHE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }

                // Section 4: Display Downscaler presets
                SettingsSectionContainer(title = "DISPLAY RESOLUTION DOWNSCALER") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("none" to "No Scaling", "720p" to "Preset 720p", "1080p" to "Preset 1080p").forEach { (preset, label) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (selectedPreset == preset) MaterialTheme.colorScheme.primary else Color(0xFF141D29), shape = RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedPreset = preset
                                        SettingsStore.setString(context, SettingsStore.KEY_DOWNSCALE_PRESET, preset)
                                        Toast.makeText(context, "Preset updated: $label", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPreset == preset) MaterialTheme.colorScheme.onPrimary else Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Manual TextInputs
                    Text("Manual Resolution Modifier Override:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customWidth,
                            onValueChange = {
                                customWidth = it
                                SettingsStore.setString(context, SettingsStore.KEY_CUSTOM_RESOLUTION, "${customWidth}x${customHeight}")
                            },
                            placeholder = { Text("Width", fontSize = 8.sp) },
                            modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary, unfocusedBorderColor = Color(0xFF2C394F))
                        )
                        OutlinedTextField(
                            value = customHeight,
                            onValueChange = {
                                customHeight = it
                                SettingsStore.setString(context, SettingsStore.KEY_CUSTOM_RESOLUTION, "${customWidth}x${customHeight}")
                            },
                            placeholder = { Text("Height", fontSize = 8.sp) },
                            modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary, unfocusedBorderColor = Color(0xFF2C394F))
                        )
                        OutlinedTextField(
                            value = customDpi,
                            onValueChange = {
                                customDpi = it
                                SettingsStore.setString(context, SettingsStore.KEY_CUSTOM_DPI, it)
                            },
                            placeholder = { Text("DPI", fontSize = 8.sp) },
                            modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary, unfocusedBorderColor = Color(0xFF2C394F))
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Dropdowns for HWUI profiles and Graphics driver runtimes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("HWUI Rendering Engine Backend", fontSize = 8.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF141D29), shape = RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0xFF2C394F), shape = RoundedCornerShape(6.dp))
                                    .clickable {
                                        val hwuiOptions = listOf("Default", "SkiaGL", "SkiaVK")
                                        val idx = hwuiOptions.indexOf(selectedHwui)
                                        selectedHwui = hwuiOptions[(idx + 1) % hwuiOptions.size]
                                        SettingsStore.setString(context, SettingsStore.KEY_HWUI_RENDERER, selectedHwui)
                                        Toast.makeText(context, "Renderer: $selectedHwui", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(8.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(selectedHwui, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Graphics Driver Preference", fontSize = 8.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF141D29), shape = RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0xFF2C394F), shape = RoundedCornerShape(6.dp))
                                    .clickable {
                                        val driverOptions = listOf("Default", "Game Driver", "System")
                                        val idx = driverOptions.indexOf(selectedDriver)
                                        selectedDriver = driverOptions[(idx + 1) % driverOptions.size]
                                        SettingsStore.setString(context, SettingsStore.KEY_GRAPHICS_DRIVER, selectedDriver)
                                        Toast.makeText(context, "Driver preference: $selectedDriver", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(8.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(selectedDriver, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }

                // Section 5: Externals & System Modifiers
                SettingsSectionContainer(title = "YOUR EXTERNALS & MODIFIERS") {
                    SettingsSwitchRow(
                        title = "Animation Master Switch (0x Disable)",
                        desc = "Speeds up transition scale values instantly to 0.0x scale",
                        checked = animationMaster,
                        onCheckedChange = {
                            animationMaster = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_ANIMATION_MASTER, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "System Wide DNS Ad-Blocker",
                        desc = "Sets system private DNS specifier to AdGuard server filters",
                        checked = isAdBlockerActive,
                        onCheckedChange = {
                            isAdBlockerActive = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_AD_BLOCKER, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "Freeze Google Core Polling",
                        desc = "Temporarily suspends background safety and polling threads",
                        checked = googleFreezeActive,
                        onCheckedChange = {
                            googleFreezeActive = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_GOOGLE_FREEZE, it)
                        }
                    )
                    SettingsSwitchRow(
                        title = "System Log Killer",
                        desc = "Disables logd buffer allocations to free CPU polling ticks",
                        checked = logKillerActive,
                        onCheckedChange = {
                            logKillerActive = it
                            SettingsStore.setBoolean(context, SettingsStore.KEY_LOG_KILLER, it)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSectionContainer(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0D1117), shape = RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF1E2638), shape = RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = title,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Divider(color = Color(0xFF1E2638), thickness = 1.dp)
            content()
        }
    }
}

@Composable
fun SettingsSwitchRow(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = desc,
                fontSize = 8.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.primary,
                checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF2C394F)
            ),
            modifier = Modifier.scale(0.8f)
        )
    }
}

// Custom simple modifier scaling for nicer switches
fun Modifier.scale(scale: Float): Modifier = this.size((48 * scale).dp, (24 * scale).dp)
