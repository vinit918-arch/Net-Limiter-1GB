package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryNeon = Color(0xFF00FF66) // Neon Green
val SecondaryCarbon = Color(0xFF1E2530) // Dark Charcoal Card
val TertiaryElectric = Color(0xFF00E5FF) // Cyber Cyan
val DarkBackground = Color(0xFF0A0D14) // Deep Dark Slate Background
val SurfaceSlate = Color(0xFF141A24) // Slightly lighter slate for inputs
val OnPrimaryDark = Color(0xFF002209)
val TextLight = Color(0xFFF0F4F8)
val TextDim = Color(0xFF8A99AD)
val SuccessGreen = Color(0xFF10B981)
val DangerRed = Color(0xFFEF4444)

