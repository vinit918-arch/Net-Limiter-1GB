package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.example.shizuku.SettingsStore
import com.example.shizuku.ShizukuShellExecutor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class GameAutomationService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isOptimizedState = false
    private var lastForegroundPackage = ""

    companion object {
        private const val TAG = "GameAutomationService"
        var isServiceConnected = false
            private set
        
        var currentForegroundApp = "None"
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnected = true
        Log.d(TAG, "GameAutomationService connected.")
        Toast.makeText(this, "Game Booster Service Connected!", Toast.LENGTH_SHORT).show()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnected = false
        Log.d(TAG, "GameAutomationService disconnected.")
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            currentForegroundApp = packageName
            
            if (packageName == lastForegroundPackage) return
            lastForegroundPackage = packageName

            val targetGames = SettingsStore.getAddedGames(this)
            
            if (targetGames.contains(packageName)) {
                // A target game entered the foreground! Trigger optimization commands
                if (!isOptimizedState) {
                    isOptimizedState = true
                    Log.d(TAG, "Game detected: $packageName. Triggering optimizations...")
                    showToast("Game Booster: Optimizing for $packageName")
                    applyGameOptimizations(packageName)
                }
            } else {
                // Exited the game (possibly back to launcher or other app)
                // Let's check if the package is NOT a launcher and NOT our app.
                // But generally, if we were in optimized state and the new app is NOT in targetGames, we should revert.
                if (isOptimizedState) {
                    isOptimizedState = false
                    Log.d(TAG, "Game exited. Reverting system settings...")
                    showToast("Game Booster: Game exited, reverting settings")
                    revertOptimizations()
                }
            }
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "GameAutomationService interrupted.")
    }

    private fun showToast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    private fun applyGameOptimizations(gamePackage: String) {
        serviceScope.launch {
            val commands = mutableListOf<String>()

            // 1. Performance Engine Toggles
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_PERF_MODE, false)) {
                commands.add("cmd power set-mode 2")
                commands.add("setprop debug.egl.hw 1")
                commands.add("setprop debug.gr.numcommonbuffers 3")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_DISABLE_POWER_SAVING, false)) {
                commands.add("settings put global low_power 0")
                commands.add("settings put global low_power_trigger_level 0")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_FORCE_HW_OVERLAYS, false)) {
                commands.add("settings put global force_msaa 1")
                commands.add("service call SurfaceFlinger 1008 i32 1")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_DISABLE_TELEMETRY, false)) {
                commands.add("device_config put latency_tracker enabled false")
                commands.add("settings put global send_action_mb_limit 0")
            }

            // 2. RAM Module Restrictions (Background trimming)
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_STOP_3RD_PARTY, false)) {
                commands.add("am kill-all")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_STOP_RECOMMENDED, false)) {
                commands.add("am trim-caches 40")
            }

            // 3. Display Downscaler
            val downscale = SettingsStore.getString(applicationContext, SettingsStore.KEY_DOWNSCALE_PRESET, "none")
            if (downscale == "720p") {
                commands.add("wm size 720x1600")
                commands.add("wm density 320")
            } else if (downscale == "1080p") {
                commands.add("wm size 1080x2400")
                commands.add("wm density 440")
            } else {
                // Custom sizes if present
                val customRes = SettingsStore.getString(applicationContext, SettingsStore.KEY_CUSTOM_RESOLUTION, "")
                val customDpi = SettingsStore.getString(applicationContext, SettingsStore.KEY_CUSTOM_DPI, "")
                if (customRes.isNotEmpty()) {
                    commands.add("wm size $customRes")
                }
                if (customDpi.isNotEmpty()) {
                    commands.add("wm density $customDpi")
                }
            }

            // HWUI Renderer
            val hwui = SettingsStore.getString(applicationContext, SettingsStore.KEY_HWUI_RENDERER, "Default")
            if (hwui != "Default") {
                commands.add("setprop debug.hwui.renderer $hwui")
            }

            // Graphics Driver
            val driver = SettingsStore.getString(applicationContext, SettingsStore.KEY_GRAPHICS_DRIVER, "Default")
            if (driver == "Game Driver") {
                commands.add("settings put global game_driver_all_apps 1")
            } else if (driver == "System") {
                commands.add("settings put global game_driver_all_apps 0")
            }

            // 4. Externals
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_ANIMATION_MASTER, false)) {
                commands.add("settings put global window_animation_scale 0.0")
                commands.add("settings put global transition_animation_scale 0.0")
                commands.add("settings put global animator_duration_scale 0.0")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_AD_BLOCKER, false)) {
                commands.add("settings put global private_dns_mode hostname")
                commands.add("settings put global private_dns_specifier dns.adguard.com")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_GOOGLE_FREEZE, false)) {
                commands.add("pm suspend com.google.android.gms")
            }
            if (SettingsStore.getBoolean(applicationContext, SettingsStore.KEY_LOG_KILLER, false)) {
                commands.add("setprop logd.limit 0")
                commands.add("logcat -c")
            }

            // Execute all commands in Shizuku
            if (commands.isNotEmpty()) {
                val script = commands.joinToString("\n")
                Log.d(TAG, "Executing optimizations script:\n$script")
                val result = ShizukuShellExecutor.executeCommand(script)
                Log.d(TAG, "Optimization execution exitCode: ${result.exitCode}")
            }
        }
    }

    private fun revertOptimizations() {
        serviceScope.launch {
            val commands = mutableListOf<String>()

            // Revert display downscaling
            commands.add("wm size reset")
            commands.add("wm density reset")

            // Revert hardware overlays
            commands.add("settings put global force_msaa 0")
            commands.add("service call SurfaceFlinger 1008 i32 0")

            // Revert animation speeds to 1x
            commands.add("settings put global window_animation_scale 1.0")
            commands.add("settings put global transition_animation_scale 1.0")
            commands.add("settings put global animator_duration_scale 1.0")

            // Revert private DNS ad blocking if set
            commands.add("settings put global private_dns_mode off")

            // Unsuspend/unfreeze Google Play services
            commands.add("pm unsuspend com.google.android.gms")

            // Restore logging limit to standard 256k
            commands.add("setprop logd.limit 262144")

            // Run command script
            val script = commands.joinToString("\n")
            Log.d(TAG, "Reverting optimizations script:\n$script")
            val result = ShizukuShellExecutor.executeCommand(script)
            Log.d(TAG, "Revert execution exitCode: ${result.exitCode}")
        }
    }
}
